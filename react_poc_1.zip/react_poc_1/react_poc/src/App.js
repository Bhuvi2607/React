import React from "react"
import './App.css';
import "./index.css";
import AddProduct from "./components/AddProduct";
import GetProduct from "./components/GetProduct";
import { BrowserRouter as Router, Route } from 'react-router-dom';
import {Switch} from 'react-router-dom';


function App() { 
  
  

  return (
    <div>
      
      <Router>
        <Switch>
            <Route   path = "/" exact component={AddProduct}></Route>
            <Route   path = "/getProduct" exact component={GetProduct}></Route>  
        </Switch>
      </Router>
  
</div>
  );
}


export default App;
