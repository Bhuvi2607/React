import React from 'react'

function GetProduct({
  newEntry, 
  show, 
  setDescription, 
  setUpdate, 
  setProduct, 
  setPrice, 
  setisEditItem, 
  setnewEntry}) {
  
    if(! show){
      return <></>
    }
    const handleUpdate=(index)=>{
        //console.log(index);
        let editItem = newEntry.find((value)=>{
          return value.id ===index;
        }
        )
        console.log(editItem);
        setUpdate(false);
        setProduct(editItem.product);
        setDescription(editItem.description);
        setPrice(editItem.price);
        setisEditItem(index);
      
        
      }

      
    const handleDelet=(e)=>{
        alert("are you sure  you want to delete this product ? ")
        let x=e.target.getAttribute("removeProduct");
        setnewEntry(newEntry.filter(items=>items.product!==x));
    
      }

  return (

    <div>
    {newEntry.map((value)=>{
     return(
      <div key={value.id} className="container">  
      <p> <b> Product Name :</b> {value.product}</p>
      <p><b> Description:</b> {value.description}</p>
      <p><b> Price:</b> {value.price}</p>
      <button className="update"  onClick={()=>handleUpdate(value.id)}> UPDATE</button>
      <button className="delete" removeProduct={value.product} onClick={handleDelet}>DELETE</button>
      </div>
     )
    })}
  </div>
    
  )
}

export default GetProduct