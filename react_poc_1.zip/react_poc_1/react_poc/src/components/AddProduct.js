import React, { useState } from "react";
// import { useHistory } from "react-router-dom";
import { BiAddToQueue } from "react-icons/bi";
import { BsFillBagFill } from "react-icons/bs";
import { HiPencilAlt } from "react-icons/hi";
import GetProduct from "./GetProduct";

function AddProduct() {
  // let history = useHistory();
  const [Product, setProduct] = useState(" ");
  const [Description, setDescription] = useState(" ");
  const [Price, setPrice] = useState(" ");

  const [newEntry, setnewEntry] = useState([]);

  const [update, setUpdate] = useState(true);

  const [isEditItem, setisEditItem] = useState(null);
  const [getProduct, setGetProduct] = useState(false);
  const [showProduct, setshowProduct] = useState(false);

  // const handleChange = (e)=>{
  //   setProduct(e.target.value);
  //   setDescription(e.target.value);
  // }

  // const handleClick = e => {

  //   console.log('clicked');
  //   setProduct(e.target.value)
  // }

  const submitData = (e) => {
    e.preventDefault();

    if (!Product || !Description || !Price) {
      alert(" please fill all the fields");
    } else if (Product && Description && Price && !update) {
      setnewEntry(
        newEntry.map((value) => {
          if (value.id === isEditItem) {
            return {
              ...value,
              product: Product,
              description: Description,
              price: Price,
            };
          }
          return value;
        })
      );
      setUpdate(true);
      setProduct("");
      setDescription("");
      setPrice("");
      setGetProduct(true);

      // history.push('/getProduct');
    } else {
      const myProducts = {
        id: new Date().getTime().toString(),
        product: Product,
        description: Description,
        price: Price,
      };
      setnewEntry([...newEntry, myProducts]);
      setProduct("");
      setDescription("");
      setPrice("");
      alert("new product added");
      setshowProduct(true);
    }
  };

  const handleDelet = (e) => {
    if (window.confirm("are you sure  you want to delete this product ?")) {
      // window.confirm("are you sure  you want to delete this product ?");
      let x = e.target.getAttribute("removeProduct");
      setnewEntry(newEntry.filter((items) => items.product !== x));
    }
  };

  const handleUpdate = (index) => {
    //console.log(index);
    let editItem = newEntry.find((value) => {
      return value.id === index;
    });
    console.log(editItem);
    setUpdate(false);
    setProduct(editItem.product);
    setDescription(editItem.description);
    setPrice(editItem.price);
    setisEditItem(index);
  };

  return (
    <div>
      <h1 className="app">
        {" "}
        <BsFillBagFill /> &nbsp; Products
      </h1>
      <div className="form-container">
        <h3 className="text">
          {" "}
          <BiAddToQueue /> &nbsp; Add Product
        </h3>
        <form className="register-form">
          <label htmlFor="product name">
            {" "}
            <HiPencilAlt />
            Product Name
          </label>
          <input
            id="product name"
            className="form-field"
            type="text"
            placeholder="Product Name"
            name="ProductName"
            value={Product}
            onChange={(e) => setProduct(e.target.value)}
          />

          <label htmlFor="Description">
            {" "}
            <HiPencilAlt /> Description
          </label>
          <input
            id="Description"
            className="form-field"
            type="text"
            placeholder="Description"
            name="Description"
            value={Description}
            onChange={(e) => setDescription(e.target.value)}
          />

          <label htmlFor="Price">
            <HiPencilAlt /> Price{" "}
          </label>
          <input
            id="Price"
            className="form-field"
            type="number"
            placeholder="Price"
            name="Price"
            value={Price}
            onChange={(e) => setPrice(e.target.value)}
          />
          {update ? (
            <button className="form-field" type="submit" onClick={submitData}>
              SUBMIT
            </button>
          ) : (
            <button className="update" onClick={submitData}>
              {" "}
              UPDATE
            </button>
          )}
          {/*         
        <button className="form-field" type="submit" >
          SUBMIT
        </button> */}
        </form>
      </div>
      <GetProduct
        show={showProduct}
        newEntry={newEntry}
        setDescription={setDescription}
        setUpdate={setUpdate}
        setProduct={setProduct}
        setPrice={setPrice}
        setisEditItem={setisEditItem}
        setnewEntry={setnewEntry}
      />
    </div>
  );
}

export default AddProduct;

/* {setGetProduct &&}*/
